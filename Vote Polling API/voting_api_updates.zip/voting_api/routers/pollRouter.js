const express = require("express");
const pollRouter = express.Router();
const {
  createPoll,
  getPoll,
  updatePoll,
  deletePoll,
} = require("../controllers/pollController");
const { checkAuthenticated } = require("../middlewares/auth");

/**
 * Routes For Poll..
 * @name get /getpoll -  get polls created by user.
 * @name POST /createpoll - create a new poll.
 * @name put /updatepoll - update a poll
 * @name delete /deletePoll - delete a  poll
 */
pollRouter.get("/getpoll", getPoll);
pollRouter.post("/createpoll",checkAuthenticated, createPoll);
pollRouter.put("/updatepoll",checkAuthenticated, updatePoll);
pollRouter.delete("/deletePoll", checkAuthenticated, deletePoll);

module.exports = {
  pollRouter,
};
