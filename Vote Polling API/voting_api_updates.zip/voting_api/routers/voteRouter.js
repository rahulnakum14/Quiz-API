const express = require("express");
const voteRouter = express.Router();
const { voteChoices,getVotes } = require("../controllers/voteController");

/**
 * Routes For Voting..
 * @name get /:id getVotes Result
 * @name post /:id  Vote to the choices
 */
voteRouter.get('/',getVotes);
voteRouter.post("/", voteChoices);


module.exports = {
  voteRouter,
};
