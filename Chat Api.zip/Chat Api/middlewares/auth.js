const authUser = (req, res, next) => {
  const isCookie = req.cookies.isLoggedIn;  
  if (!isCookie) {
    return res.status(401).json({
      message: "User Is not Authorized",
    });
  }
 
  return next();
};

module.exports = {
  authUser,
};

