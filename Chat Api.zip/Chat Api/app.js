const express = require("express");
const http = require("http");
const socketIO = require("socket.io");
const initializeSocketIO = require("./socketManager");
const { sequelize } = require("./config/db");
const path = require("path");
const app = express();
const server = http.createServer(app);
const io = socketIO(server);
const cookieParser = require("cookie-parser");
const { authUser } = require("./middlewares/auth");
const { userRouter } = require("./Router/userRouter");

app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(__dirname + "/uploads"));
app.use(express.json());
app.use("/", userRouter);

app.get("/chatapp", authUser, (req, res) => {
  res.sendFile(path.join(__dirname, "uploads", "index.html"));
});
initializeSocketIO(io);

async function startServer() {
  try {
    await sequelize.authenticate();
    console.log("Connection to database has been authenticated successfully.");
    await sequelize.sync({ alter: true, force: false });
    console.log("Database schema has been synchronized.");
    server.listen(5000, () => {
      console.log(`Server is running on port 5000`);
    });
  } catch (error) {
    console.error(
      "Error connecting to database or synchronizing schema:",
      error
    );
  }
}

startServer();
