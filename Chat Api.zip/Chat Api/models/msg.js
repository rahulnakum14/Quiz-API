const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/db");

const msgs = sequelize.define("msg", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  content: {
    type: DataTypes.TEXT,
  }
},{
  timestamps:false
});


module.exports = {
    msgs
};