// user.js
const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/db");
const { msgs } = require("./msg"); 

const user = sequelize.define(
  "user",
  {
    username: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        len: {
          args: [5],
          msg: "Password should be at least 5 characters long",
        },
      },
    },
  },
  {
    timestamps: false,
  }
);

user.hasMany(msgs, { foreignKey: "senderId" });
user.hasMany(msgs, { foreignKey: "receiverId" });

module.exports = {
  user,
};
