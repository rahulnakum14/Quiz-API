const { Router } = require("express");
const userRouter = Router();
const {
  registerUser,
  loginUser,
  loginPageget,
  registerPageget,
  logoutUser
} = require("../controller/userController");

userRouter.get("/login", loginPageget);
userRouter.post("/login", loginUser);
userRouter.get("/register", registerPageget);
userRouter.post("/register", registerUser);
userRouter.get("/logout", logoutUser);


module.exports = {
  userRouter,
};
