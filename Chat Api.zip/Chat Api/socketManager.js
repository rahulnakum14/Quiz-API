const activeUser = [];
const { msgs } = require("./models/msg");
const { user } = require("./models/user");
const { Op } = require("sequelize");

const initializeSocketIO = (io) => {
  io.on("connection", (socket) => {
    console.log("a user connected");

    const cookies = socket.handshake.headers.cookie.split(";");
    let loggedInUser;

    for (const cookie of cookies) {
      const [key, value] = cookie.trim().split("=");
      if (key === "username") {
        loggedInUser = decodeURIComponent(value);
        break;
      }
    }
    if (loggedInUser) {
      activeUser.push(loggedInUser);
      socket.emit("loggedInUser", loggedInUser);
    }

    socket.on("user list", () => {
      try {
        const activeUsernames = activeUser.filter(
          (user) => user !== loggedInUser
        );
        socket.emit("user list", Array.from(activeUsernames));
      } catch (error) {
        console.error("Error fetching user list:", error);
      }
    });

    socket.on("chat message", async (msg) => {
      try {
        const senderUsername = loggedInUser;
        const receiverUsername = msg.to;

        if(senderUsername === receiverUsername){
          io.emit('private message',{
            msg:"User Cannot send Msg to them selves"
          })
          return
        }
        const sender = await user.findOne({
          where: { username: senderUsername },
        });

        const receiver = await user.findOne({
          where: { username: receiverUsername },
        });

        if (!sender || !receiver) {
          throw new Error("Sender not found.");
        }

        if (!receiver) {
          throw new Error("Reciver not found.");
        }

        const newMsg = await msgs.create({
          content: msg.content,
          senderId: sender.id,
          receiverId: receiver.id,
        });

        io.emit("private message", {
          from: senderUsername,
          to: receiverUsername,
          content: msg.content,
        });
      } catch (error) {
        console.error("Error saving message to database:", error);
      }
    });

    socket.on("request user messages", async (selectedUser) => {
      try {
        const user1 = await user.findOne({ where: { username: selectedUser } });

        if (!user1) {
          throw new Error("User not found");
        }
        const messages = await msgs.findAll({
          where: {
            [Op.or]: [{ receiverId: user1.id }, { senderId: user1.id }],
          },
        });
        const messagesWithSenderNames = await Promise.all(
          messages.map(async (msg) => {
            const sender = await user.findByPk(msg.senderId);
            const receiver = await user.findByPk(msg.receiverId);
            return {
              senderName: sender.username,
              receiverUsername: receiver.username,
              content: msg.content,
            };
          })
        );

        socket.emit("user messages", messagesWithSenderNames);
      } catch (error) {
        console.error("Error retrieving user messages:", error);
      }
    });

    socket.on("disconnect", () => {
      const index = activeUser.indexOf(loggedInUser);
      if (index !== -1) {
        activeUser.splice(index, 1);
      }
    });
  });
};

module.exports = initializeSocketIO;
