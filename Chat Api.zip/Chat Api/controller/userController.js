const { user } = require("../models/user");
const path = require("path");

const loginPageget = (req, res) => {
  res.sendFile(path.join(__dirname, "..", "uploads", "login.html"));
};

const registerPageget = (req, res) => {
  res.sendFile(path.join(__dirname, "..", "uploads", "register.html"));
};

const registerUser = async (req, res) => {
  const { username, password } = req.body;
  try {
    const newUser = await user.create({
      username: username,
      password: password,
    });
    return res.status(201).json({
      message: "User is registerd",
      newUser,
    });
  } catch (error) {
    return res.status(500).json({
      message: "Something Went Wrong While Creating A new User",
      error,
    });
  }
};

const loginUser = async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({
      message: "Please Enter username and password",
    });
  }
  try {
    if (username && password) {
      const isUserExist = await user.findOne({
        where: {
          username: username,
        },
      });
      if (!isUserExist) {
        return res.status(404).json({
          message: "Invalid username or password..",
        });
      }
      if (password === isUserExist.password) {
        res.cookie("username", isUserExist.username);
        res.cookie("isLoggedIn", true);
        res.redirect('/chatapp');
      } else {
        return res.status(403).json({
          message: "Invalid username or password..",
        });
      }
    }
  } catch (error) {
    return res.status(500).json({
      message: "Something Went Wrong While Login a new User",
      error,
    });
  }
};

const logoutUser = (req, res) => {
  try {
    res.clearCookie("isLoggedIn");
    res.redirect('/login');
  } catch (error) {
    return res.status(500).json({
      message: "Something went wrong while logging out",
      error: error.message,
    });
  }
};

module.exports = {
  registerUser,
  loginUser,
  loginPageget,
  registerPageget,
  logoutUser
};
